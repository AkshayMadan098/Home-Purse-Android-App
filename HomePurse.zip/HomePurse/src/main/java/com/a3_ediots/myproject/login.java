package com.a3_ediots.myproject;


import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class login extends AppCompatActivity {
    AlertDialog.Builder ab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button b1=findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView num = findViewById(R.id.et1);
                TextView password = findViewById(R.id.et2);
                if (num.getText().toString().isEmpty()) {
                    ab = new AlertDialog.Builder(login.this);
                    ab.setTitle("Warning");
                    ab.setMessage("Phone number is Empty..!! It should Contain a valid Number...!!!");
                    ab.show();
                } else {
                    SharedPreferences sp = getSharedPreferences("HomePurse", 0);
                    SharedPreferences user;
                    String phone,pass;
                    int users = sp.getInt("users", 0) + 1;
                    Log.e("users",""+users);
                    for (int i = 1; i < users; i++) {
                        user = getSharedPreferences("user" + i, 0);
                        phone = user.getString("phone", null);
                        pass = user.getString("pass", null);
                        Log.e("name", "" + phone);
                        Log.e("users", "" + pass);
                        try {
                            if (phone.equals(num.getText().toString())) {
                                if (pass.equals(password.getText().toString())) {
                                    startActivity(new Intent(getApplicationContext(), Home.class));

                                    break;
                                } else {
                                    ab = new AlertDialog.Builder(login.this);
                                    ab.setTitle("Warning");
                                    ab.setMessage("Password incorrect...!!!");
                                    ab.show();
                                    break;
                                }
                            }
                            if (i == users-1) {
                                ab = new AlertDialog.Builder(login.this);
                                ab.setTitle("Warning");
                                ab.setMessage("Account not found first Register yourself...!!!");
                                ab.show();

                            }
                        } catch (Exception e) {
                            Log.e("error",e.toString());
                        }
                    }
                }
            }
        });
        TextView tv=findViewById(R.id.textView5);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });
    }
}
