package com.a3_ediots.myproject;


import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Register extends AppCompatActivity {

    AlertDialog.Builder ab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Button b=findViewById(R.id.b1);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView city=findViewById(R.id.tv3);
                TextView name=findViewById(R.id.tv4);
                TextView phone=findViewById(R.id.tvv4);
                TextView email=findViewById(R.id.tv5);
                TextView pass=findViewById(R.id.tv6);
                if(city.getText().toString().isEmpty())
                {
                    ab=new AlertDialog.Builder(Register.this);
                    ab.setTitle("Warning");
                    ab.setMessage("You should Select a city for renting your house...!!!");
                    ab.show();
                }
                else
                if(name.getText().toString().isEmpty())
                {
                    ab=new AlertDialog.Builder(Register.this);
                    ab.setTitle("Warning");
                    ab.setMessage("Name is Empty..!! Name can not be Empty...!!!");
                    ab.show();
                }
                else
                if(phone.getText().toString().isEmpty())
                {
                    ab=new AlertDialog.Builder(Register.this);
                    ab.setTitle("Warning");
                    ab.setMessage("Phone number is Empty..!! Phone number is a Required Field...!!!");
                    ab.show();
                }
                else
                if(phone.getText().toString().length()!=10)
                {
                    ab=new AlertDialog.Builder(Register.this);
                    ab.setTitle("Warning");
                    ab.setMessage("Not a valid number...!!!");
                    ab.show();
                }
                else {
                    SharedPreferences sp=getSharedPreferences("HomePurse",0);

                    int users=sp.getInt("users",0)+1;

                    SharedPreferences.Editor edt=sp.edit();
                    edt.putInt("users",users);
                    edt.commit();
                    SharedPreferences newuser=getSharedPreferences("user"+(users),0);
                    SharedPreferences.Editor editor=newuser.edit();
                    editor.putString("name",name.getText().toString());
                    editor.putString("city",city.getText().toString());
                    editor.putString("phone",phone.getText().toString());
                    editor.putString("email",email.getText().toString());
                    editor.putString("pass",pass.getText().toString());
                    editor.commit();
                    startActivity(new Intent(getApplicationContext(), Home.class));
                }
            }
        });
        View v=findViewById(R.id.tv7);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),login.class));
            }
        });

    }
}
