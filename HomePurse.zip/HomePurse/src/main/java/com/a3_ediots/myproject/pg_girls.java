package com.a3_ediots.myproject;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class pg_girls extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg_girls);
    }
}
